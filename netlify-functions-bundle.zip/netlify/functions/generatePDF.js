const PDFDocument = require("pdfkit");

exports.handler = async () => {
  const doc = new PDFDocument();
  let buffers = [];
  doc.on("data", buffers.push.bind(buffers));

  doc.fontSize(20).text("Packed Delivery Receipt", { align: "center" });
  doc.moveDown();
  doc.fontSize(12).text("Thank you for choosing Packed Delivery.");

  doc.end();

  return {
    statusCode: 200,
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": "attachment; filename=receipt.pdf"
    },
    body: Buffer.concat(buffers).toString("base64"),
    isBase64Encoded: true
  };
};