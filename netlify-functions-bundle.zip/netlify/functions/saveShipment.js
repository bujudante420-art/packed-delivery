const fetch = require("node-fetch");

exports.handler = async (event) => {
  const data = JSON.parse(event.body || "{}");

  await fetch("https://api.airtable.com/v0/YOUR_BASE/Shipments", {
    method: "POST",
    headers: {
      "Authorization": "Bearer YOUR_AIRTABLE_KEY",
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ fields: data })
  });

  return { statusCode: 200, body: "saved" };
};