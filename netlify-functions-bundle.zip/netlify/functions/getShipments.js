const fetch = require("node-fetch");

exports.handler = async () => {
  const res = await fetch("https://api.airtable.com/v0/YOUR_BASE/Shipments", {
    headers: { "Authorization": "Bearer YOUR_AIRTABLE_KEY" }
  });

  const json = await res.json();
  const records = json.records.map(r => r.fields);

  return {
    statusCode: 200,
    body: JSON.stringify(records)
  };
};