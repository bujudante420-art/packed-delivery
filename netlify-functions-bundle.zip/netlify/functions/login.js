exports.handler = async (event) => {
  const { email, password } = JSON.parse(event.body || "{}");

  if (email === "admin@packeddelivery.com" && password === "ADMIN_PASSWORD") {
    return { statusCode: 200, body: "ok" };
  }
  return { statusCode: 401, body: "unauthorized" };
};